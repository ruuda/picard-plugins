# Artist Variables Plugin

## Album Variables

* **_PriAArtistID** - The ID of the primary / first album artist listed
* **_PriAArtistStd** - The primary / first album artist listed (standardized)
* **_PriAArtistCred** - The primary / first album artist listed (as credited)
* **_PriAArtistSort** - The primary / first album artist listed (sort name)
* **_AdditionalAArtistID** - The IDs of all album artists listed except for the primary / first artist, separated by a semicolon and space
* **_AdditionalAArtistStd** - All album artists listed (standardized) except for the primary / first artist, separated with strings provided from the release entry
* **_AdditionalAArtistCred** - All album artists listed (as credited) except for the primary / first artist, separated with strings provided from the release entry
* **_FullAArtistStd** - All album artists listed (standardized), separated with strings provided from the release entry
* **_FullAArtistCred** - All album artists listed (as credited), separated with strings provided from the release entry
* **_FullAArtistSort** - All album artists listed (sort names), separated with strings provided from the release entry
* **_FullAArtistPriSort** - The primary / first album artist listed (sort name) followed by all additional album artists (standardized), separated with strings provided from the release entry
* **_AArtistCount** - The number of artists listed as album artists

## Track Variables

* **_PriTArtistID** - The ID of the primary / first track artist listed
* **_PriTArtistStd** - The primary / first track artist listed (standardized)
* **_PriTArtistCred** - The primary / first track artist listed (as credited)
* **_PriTArtistSort** - The primary / first track artist listed (sort name)
* **_AdditionalTArtistID** - The IDs of all track artists listed except for the primary / first artist, separated by a semicolon and space
* **_AdditionalTArtistStd** - All track artists listed (standardized) except for the primary / first artist, separated with strings provided from the track entry
* **_AdditionalTArtistCred** - All track artists listed (as credited) except for the primary / first artist, separated with strings provided from the track entry
* **_FullTArtistStd** - All track artists listed (standardized), separated with strings provided from the track entry
* **_FullTArtistCred** - All track artists listed (as credited), separated with strings provided from the track entry
* **_FullTArtistSort** - All track artists listed (sort names), separated with strings provided from the track entry
* **_FullTArtistPriSort** - The primary / first track artist listed (sort name) followed by all additional track artists (standardized), separated with strings provided from the track entry
* **_TArtistCount** - The number of artists listed as track artists
